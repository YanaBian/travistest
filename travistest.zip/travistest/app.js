const Koa = require('koa');
const app = new Koa();
const router = require('koa-simple-router');
const convert = require('koa-convert');
const path = require('path');
const serve = require('koa-static');

app.use(router(_ => {
    _.get('/', (ctx, next) => {
        ctx.body = 'this is a koa2 demo';
    })
}));
app.use(convert(serve(path.join(__dirname, './public')))); //静态资源文件
// app.listen(3003, () => {
//     console.log('Server Start');
// });
app.listen(3003);
module.exports = app;